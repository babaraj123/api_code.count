//
//  DataModel.swift
//  API_Demo
//
//  Created by Keyur on 03/10/24.
//

import Foundation

struct ResponseDataModel<T: Codable>: Codable {
    var result :Int?
    var message: String?
    var data:[NationData]?
}


// MARK: - NationData
struct NationData: Codable {
    let idNation: String?
    let nation: String?
    let idYear: Int?
    let year: String?
    let population: Int?
    let slugNation: String?
    var countLike: Int?

    enum CodingKeys: String, CodingKey {
        case idNation = "ID Nation"
        case nation = "Nation"
        case idYear = "ID Year"
        case year = "Year"
        case population = "Population"
        case slugNation = "Slug Nation"
        case countLike
    }
}
