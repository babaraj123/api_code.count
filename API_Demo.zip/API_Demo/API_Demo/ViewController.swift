//
//  ViewController.swift
//  API_Demo
//
//  Created by Keyur on 03/10/24.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var tblUSAData: UITableView!
    @IBOutlet weak var btnNext: UIButton!
    
    @IBOutlet weak var btnLikePage: UIButton!
    
    @IBOutlet weak var lblCount: UILabel!
    
    private var usaData = [NationData]()
    private var refreshControl = UIRefreshControl()
    
    var talkLikeValue: Int? = 0
    var isFilteringLikedData = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tblUSAData.delegate = self
        tblUSAData.dataSource = self
        btnNext.setTitle("Next", for: .normal)
        
        self.APIData()
        refreshControl = UIRefreshControl()
        tblUSAData.addSubview(refreshControl)
        refreshControl.addTarget(self, action: #selector(refreshLocumProfile), for: .valueChanged)
        
        lblCount.text = "Like :- 0    ||    DisLike :- 0 "
        
    }
    
    @objc func refreshLocumProfile() {
        
        //Clear old data
        tblUSAData.reloadData()
        refreshControl.endRefreshing()
        self.APIData()
    }
    @IBAction func btnLikePage_Clicked(_ sender: Any) {
        
    }
    
    @IBAction func btnNext_Clicked(_ sender: Any) {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let secondViewController = storyBoard.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
        self.present(secondViewController, animated:true, completion:nil)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return usaData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "USADataCell", for: indexPath) as! USADataCell
        cell.lblIdNation.text = "ID Nation :- " + (usaData[indexPath.row].idNation ?? "")
        cell.lblNation.text = "Nation :- " + (usaData[indexPath.row].nation ?? "")
        cell.lblIdYear.text = "ID Year :- " + "\(usaData[indexPath.row].idYear ?? 0)"
        cell.lblYear.text = "Year :- " + (usaData[indexPath.row].year ?? "")
        cell.lblPopulation.text = "Population :- " + "\(usaData[indexPath.row].population ?? 0)"
        cell.lblSlugNation.text = "SlugNation :- " + (usaData[indexPath.row].slugNation ?? "")
        
        cell.tag = indexPath.row
        cell.btnFevorite.addTarget(self, action: #selector(btnFevorite_CLicked(_:)), for: .touchDown)
        cell.btnFevorite.tag = indexPath.row
        
        cell.btnUNFevorite.addTarget(self, action: #selector(btnUNFevorite_CLicked(_:)), for: .touchDown)
        cell.btnUNFevorite.tag = indexPath.row
        
        var like: Bool = false
        var dislike: Bool = false
        
        if usaData[indexPath.row].countLike == 0 {
            
        } else if usaData[indexPath.row].countLike == 1 {
            like = true
        } else if usaData[indexPath.row].countLike == 2 {
            dislike = true
        }
        
        cell.btnFevorite.setImage(UIImage(systemName: like ? "hand.thumbsup.fill" : "hand.thumbsup"), for: .normal)
        cell.btnUNFevorite.setImage(UIImage(systemName: dislike ? "hand.thumbsdown.fill" : "hand.thumbsdown"), for: .normal)
       
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("You selected cell #\(indexPath.row)!")
        
    }
    
    @objc func btnFevorite_CLicked(_ sender: AnyObject) {
        if usaData[sender.tag].countLike == 1 {
            usaData[sender.tag].countLike = 0
        } else {
            usaData[sender.tag].countLike = 1
        }
        updateData()
        tblUSAData.reloadData()
    }
    
    @objc func btnUNFevorite_CLicked(_ sender: AnyObject) {
        if usaData[sender.tag].countLike == 2 {
            usaData[sender.tag].countLike = 0
        } else {
            usaData[sender.tag].countLike = 2
        }
        
        updateData()
        tblUSAData.reloadData()
    }
    
    func updateData() {
        
        let likeCount = usaData.filter { $0.countLike == 1 }
               isFilteringLikedData = true
               tblUSAData.reloadData()
        
        let dislikeCountArr = usaData.filter { $0.countLike == 2 }
                isFilteringLikedData = true
                tblUSAData.reloadData()
        
        lblCount.text = "Like :- \(likeCount.count)    ||    DisLike :- \(dislikeCountArr.count) "
    }
    
    func APIData() {
        
        var request = URLRequest(url: URL(string: "https://datausa.io/api/data?drilldowns=Nation&measures=Population")!)
        request.httpMethod = "GET"
        
        URLSession.shared.dataTask(with: request, completionHandler: { data, response, error -> Void in
            
            if(error == nil){
                
                do {
                    let responseData = try JSONDecoder().decode(ResponseDataModel<NationData?>.self, from: data!)
                    if let val = responseData.data {
                        self.usaData = val
                        print(self.usaData)
                    }
                }
                catch {
                    debugPrint(error.localizedDescription)
                }
            }
        }).resume()
    }
}


//TableView Cell
class USADataCell: UITableViewCell {
    
    @IBOutlet weak var stackMain: UIStackView!
    
    @IBOutlet weak var lblIdNation: UILabel!
    @IBOutlet weak var lblNation: UILabel!
    @IBOutlet weak var lblIdYear: UILabel!
    @IBOutlet weak var lblYear: UILabel!
    @IBOutlet weak var lblPopulation: UILabel!
    @IBOutlet weak var lblSlugNation: UILabel!
    
    @IBOutlet weak var btnFevorite: UIButton!
    @IBOutlet weak var btnUNFevorite: UIButton!
    
    
}

